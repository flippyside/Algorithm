#include "bullet.h"

// void BulletManager::TowerAttackEnemy(Tower* t, Enemy* e){
//     Bullet b;
//     TowerType towerType = t->getType();
//     b.position = t->getPosition();
//     int ap = t->getAttackPower();
//     int df = e->getDefence();
//     if(t->findSpecial(Special::awake)){
//         ap *= 2;
//     }
//     if(t->findSpecial(Special::icy)){
        
//     }
//     if(t->findSpecial(Special::poison)){

//     }
    
//     b.damage = ap - df;


//     bullets.push_back(b);

// }


#include "globalattribute.h"

// 初始化静态成员变量
int GlobalAttributes::defaultAttackPower = 50;  // 默认攻击力
int GlobalAttributes::defaultHP = 500; // 默认生命值
int GlobalAttributes::defaultDefence = 20;

#ifndef MAINSCENE_H
#define MAINSCENE_H

class mainScene
{
public:
    mainScene();
    void  initScene();
    void enemyToScene();
};

#endif // MAINSCENE_H
